<?php
	include_once 'Controller/controller.php';
	$controller = new Controller();
	$controller->View();
